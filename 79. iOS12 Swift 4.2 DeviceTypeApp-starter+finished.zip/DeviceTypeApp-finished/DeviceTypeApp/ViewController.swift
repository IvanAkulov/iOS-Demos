//
//  ViewController.swift
//  DeviceTypeApp
//
//  Created by Alexey Efimov on 18/03/2019.
//  Copyright © 2019 Alexey Efimov. All rights reserved.
//

import UIKit
import Device

class ViewController: UIViewController {

    @IBOutlet var label: UILabel!
    @IBOutlet var helloButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupLabel()
        setupButton()
    }

    @IBAction func helloButtonPressed() {
        label.isHidden = false
    }
    
    private func setupLabel() {
        
        label.isHidden = true
        label.font = UIFont(name: "Menlo-Regular",
                            size: Device.size() == Size.screen4Inch ? 30 : 40)
        label.textColor = .red
        label.textAlignment = .center
    }
    
    private func setupButton() {
        
        helloButton.layer.cornerRadius = 10
        helloButton.setTitle("Say Hello!", for: .normal)
        helloButton.setTitleColor(.white, for: .normal)
        helloButton.titleLabel?.font = UIFont(name: "Menlo-Regular",
                                              size: Device.size() == Size.screen4Inch ? 30 : 40)
    }
    
}

