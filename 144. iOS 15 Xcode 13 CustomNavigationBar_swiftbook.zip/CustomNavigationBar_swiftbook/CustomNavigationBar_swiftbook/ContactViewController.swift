//
//  ContactViewController.swift
//  CustomNavigationBar_swiftbook
//
//  Created by Сергей Горбачёв on 31.07.2021.
//

import UIKit

class ContactViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        view.backgroundColor = #colorLiteral(red: 0.9490196078, green: 0.9490196078, blue: 0.968627451, alpha: 1)
        setupViews()
    }
    
    private func setupViews() {
        createCustomNavigationBar()
        
        let audioRightButton = createCustomButton(
            imageName: "phone",
            selector: #selector(audioRightButtonTapped)
        )
        let videoRightButton = createCustomButton(
            imageName: "video",
            selector: #selector(videoRightButtonTapped)
        )
        let customTitleView = createCustomTitleView(
            contactName: "Swiftbook",
            contactDescription: "New lesson...",
            contactImage: "swift"
        )
        
        navigationItem.rightBarButtonItems = [audioRightButton, videoRightButton]
        navigationItem.titleView = customTitleView
    }
    
    @objc private func audioRightButtonTapped() {
        print("audioRightButtonTapped")
    }
    
    @objc private func videoRightButtonTapped() {
        print("videoRightButtonTapped")
    }
}
