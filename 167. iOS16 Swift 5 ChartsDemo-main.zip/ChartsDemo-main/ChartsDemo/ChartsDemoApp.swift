//
//  ChartsDemoApp.swift
//  ChartsDemo
//
//  Created by Vasichko Anna on 29.07.2022.
//

import SwiftUI

@main
struct ChartsDemoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
