import UIKit

// 0000 0
// 0001 1
// 0010 2
// 0011 3
// 0100 4
// 0101 5
// 0110 6
// 0111 7
// 1000 8
// 1001 9
// 1010 10  (A)
// 1011 11  (B)
// 1100 12  (C)
// 1101 13  (D)
// 1110 14  (E)
// 1111 15  (F)

//#FFFFFF
//F    F    F    F    F    F
//1111 1111 1111 1111 1111 1111

//#000000
//0000 0000 0000 0000 0000 0000

//#FF0000
//1111 1111 0000 0000 0000 0000
//0000 0000 0000 0000 1111 1111 // red
//0b11111111 // 0...255 // 256

//#FF00CC

UIColor(red: 255 / 255, green: 255 / 255, blue: 255 / 255, alpha: 1.0)

func getColorFrom(hexColor hex: Int, withAlpha alpha: CGFloat) -> UIColor {
    
    let red = (hex & 0xFF0000) >> 16
    let green = (hex & 0x00FF00) >> 8
    let blue = (hex & 0x0000FF)
    
    return UIColor(red: CGFloat(red) / 255, green: CGFloat(green) / 255, blue: CGFloat(blue) / 255, alpha: alpha)
}

let color = getColorFrom(hexColor: 0xCC2ED1, withAlpha: 1.0)
color

extension UIColor {
    convenience init? (hexValue: String, alpha: CGFloat) {
        if hexValue.hasPrefix("#") {
            let scanner = Scanner(string: hexValue)
            scanner.scanLocation = 1
            
            var hexInt32: UInt32 = 0
            if hexValue.count == 7 {
                if scanner.scanHexInt32(&hexInt32) {
                    let red = CGFloat((hexInt32 & 0xFF0000) >> 16) / 255
                    let green = CGFloat((hexInt32 & 0x00FF00) >> 8) / 255
                    let blue = CGFloat(hexInt32 & 0x0000FF) / 255
                    self.init(red: red, green: green, blue: blue, alpha: alpha)
                    return
                }
            }
        }
        return nil
    }
}

let blueColor = UIColor(hexValue: "#2863D1", alpha: 1.0)

