//
//  ViewController.swift
//  TestGesture
//
//  Created by Anastasia Sokolan on 14.12.2020.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var textField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let tapRecognizer = UITapGestureRecognizer(target: self, action: #selector(self.handleTapGesture))
        view.addGestureRecognizer(tapRecognizer)
    }

    @IBAction func tappedActionButton(_ sender: Any) {
        let modalViewController = ModalViewController()
        modalViewController.modalPresentationStyle = .fullScreen
        present(modalViewController, animated: true, completion: nil)
    }
    
    @objc private func handleTapGesture(sender: UITapGestureRecognizer) {
        textField.resignFirstResponder()
    }
}

