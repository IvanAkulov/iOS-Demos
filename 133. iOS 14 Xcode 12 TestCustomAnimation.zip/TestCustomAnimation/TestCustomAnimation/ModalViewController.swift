//
//  ModalViewController.swift
//  TestCustomAnimation
//
//  Created by Anastasia Sokolan on 29.11.2020.
//

import UIKit

class ModalViewController: UIViewController {
    private let button = UIButton()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
     }
    
    @objc func onButtonTap() {
        presentingViewController?.dismiss(animated: true, completion: nil)
    }
    
    private func setup() {
        view.addSubview(button)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitle("Dismiss", for: .normal)
        button.setTitleColor(.white, for: .normal)
        
        NSLayoutConstraint.activate([
            button.widthAnchor.constraint(equalToConstant: 80),
            button.heightAnchor.constraint(equalToConstant: 40),
            button.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            button.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20.0)
        ])
        
        view.backgroundColor = .blue
        button.addTarget(self, action: #selector(onButtonTap), for: .touchUpInside)
    }
}
