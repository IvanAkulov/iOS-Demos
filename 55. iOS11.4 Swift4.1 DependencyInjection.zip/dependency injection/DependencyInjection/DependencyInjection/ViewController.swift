//
//  ViewController.swift
//  DependencyInjection
//
//  Created by Ivan Akulov on 17/07/2018.
//  Copyright © 2018 Ivan Akulov. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var networkManager: NetworkManager

    override func viewDidLoad() {
        super.viewDidLoad()
        
        networkManager.getData()
    }
    
    init(networkManager: NetworkManager) {
        self.networkManager = networkManager
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

