//
//  AppDelegate.swift
//  DependencyInjection
//
//  Created by Ivan Akulov on 17/07/2018.
//  Copyright © 2018 Ivan Akulov. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?


    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {
        
//        let networkManager = NetworkManager()
//        if let rootViewController = window?.rootViewController as? ViewController {
//            rootViewController.networkManager = networkManager
//        }
        
        let networkManager = NetworkManager()
        let viewController = ViewController(networkManager: networkManager)
        let window = UIWindow(frame: UIScreen.main.bounds)
        window.rootViewController = viewController
        window.makeKeyAndVisible()
        self.window = window
        
        return true
    }
}









