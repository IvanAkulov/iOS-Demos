//
//  ViewController.swift
//  TableViewAppWithEnum
//
//  Created by Ivan Akulov on 12/09/2018.
//  Copyright © 2018 Ivan Akulov. All rights reserved.
//

import UIKit

enum TableViewSections: String, CaseIterable {
    case general
    case personal
    case contacts
    case whatever
}

class TableViewController: UITableViewController {

    let dictionary = [TableViewSections.general.rawValue: ["Country: Russia", "City: Ufa", "Street: Komsomolskaya"],
                      TableViewSections.personal.rawValue: ["Name: Ivan", "Age: 33", "Hair color: Whatever"],
                      TableViewSections.contacts.rawValue: ["Telephone: 333-33-333", "Email adress: info@swiftbook.ru"]]
   
    override func numberOfSections(in tableView: UITableView) -> Int {
        return TableViewSections.allCases.count
    }
    
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return TableViewSections.allCases[section].rawValue.capitalized
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let key = TableViewSections.allCases[section].rawValue
        guard let values = dictionary[key] else { return 0 }
        return values.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        let key = TableViewSections.allCases[indexPath.section].rawValue
        let value = dictionary[key]?[indexPath.row]
        
        cell.textLabel?.text = value
        
        return cell
    }
    
    override func tableView(_ tableView: UITableView, willDisplayHeaderView view: UIView, forSection section: Int) {
        if let headerView = view as? UITableViewHeaderFooterView {
            headerView.backgroundView?.backgroundColor = #colorLiteral(red: 0.7547009485, green: 1, blue: 0.7412622462, alpha: 1)
        }
    }
}

