//
//  PropertyWrappersTests.swift
//  PropertyWrappersTests
//
//  Created by Vitaliy Podolskiy on 10.02.2021.
//

import XCTest
@testable import PropertyWrappers

class PropertyWrappersTests: XCTestCase {
    func test_stringMustBeTrimmed() {
        let string1 = " 0000 "
        let trimmed1 = TrimmedProperty(string: string1)
        XCTAssertEqual(trimmed1.string, "0000")
        
        let string2 = " 1111 1111 "
        let trimmed2 = TrimmedProperty(string: string2)
        XCTAssertEqual(trimmed2.string, "1111 1111")
    }
    
    func test_boolValueMustBeTrue() {
        DefaultsSettings.isHidden = true
        XCTAssertEqual(DefaultsSettings.isHidden, true)
    }
}

extension PropertyWrappersTests {
    private struct TrimmedProperty {
        @Trimmed var string: String
    }
    
    private struct DefaultsSettings {
        @Defaults<Bool>(key: "isHidden") static var isHidden
    }
}
