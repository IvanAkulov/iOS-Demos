//
//  ViewController.swift
//  PropertyWrappers
//
//  Created by Vitaliy Podolskiy on 10.02.2021.
//

import Cocoa

class ViewController: NSViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override var representedObject: Any? {
        didSet {
        // Update the view, if already loaded.
        }
    }

}

