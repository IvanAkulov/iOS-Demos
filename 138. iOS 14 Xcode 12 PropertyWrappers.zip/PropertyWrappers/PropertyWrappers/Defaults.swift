//
//  Defaults.swift
//  PropertyWrappers
//
//  Created by Vitaliy Podolskiy on 10.02.2021.
//

import Foundation

@propertyWrapper
struct Defaults<T> {
    let key: String
    private let storage: UserDefaults = .standard
    
    var wrappedValue: T? {
        get {
            storage.value(forKey: key) as? T
        }
        set {
            storage.setValue(newValue, forKey: key)
        }
    }
}
