//
//  ViewController.swift
//  AuthApp
//
//  Created by brubru on 23.12.2022.
//

import UIKit

//MARK: - AuthViewController
final class AuthViewController: UIViewController {
    
    //MARK: - Private Property
    private let registerTextField = RegisterTextField(placeholder: "Enter your password")
    private let eyeButton = EyeButton()
    
    private var isPrivate = true

    //MARK: - Override Methods
    override func viewDidLoad() {
        super.viewDidLoad()
        setupView()
    }
    
    //MARK: - Actions
    @objc
    private func displayBookMarks() {
        let imageName = isPrivate ? "eye" : "eye.slash"
        
        registerTextField.isSecureTextEntry.toggle()
        eyeButton.setImage(UIImage(systemName: imageName), for: .normal)
        isPrivate.toggle()
    }
}

//MARK: - Setting Views
private extension AuthViewController {
    func setupView() {
        view.backgroundColor = .systemCyan
        addSubViews()
        addActions()
        
        setupPasswordTF()
        
        setupLayout()
    }
}

//MARK: - Setting
private extension AuthViewController {
    func addSubViews() {
        view.addSubview(registerTextField)
    }
    
    func addActions() {
        eyeButton.addTarget(self, action: #selector(displayBookMarks), for: .touchUpInside)
    }
    
    func setupPasswordTF() {
        registerTextField.delegate = self
        registerTextField.rightView = eyeButton
        registerTextField.rightViewMode = .always
    }
}

//MARK: - Layout
private extension AuthViewController {
    func setupLayout() {
        registerTextField.translatesAutoresizingMaskIntoConstraints = false
        
        registerTextField.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        registerTextField.centerYAnchor.constraint(equalTo: view.centerYAnchor).isActive = true
        registerTextField.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 0.8).isActive = true
    }
}

extension AuthViewController: UITextFieldDelegate {
    func textFieldDidChangeSelection(_ textField: UITextField) {
        guard let text = textField.text else { return }
        eyeButton.isEnabled = !text.isEmpty
    }
}
