//
//  ViewController.swift
//  XibNibProject
//
//  Created by Сергей Вихляев on 26.03.2022.
//

import UIKit

class ViewController: UIViewController {

	@IBAction func nextButtonDidTap(_ sender: Any) {

		let anotherVC = AnotherViewController()
		navigationController?.pushViewController(anotherVC, animated: true)
	}
}

