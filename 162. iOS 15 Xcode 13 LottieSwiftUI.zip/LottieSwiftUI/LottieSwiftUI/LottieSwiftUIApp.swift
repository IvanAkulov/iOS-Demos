//
//  LottieSwiftUIApp.swift
//  LottieSwiftUI
//
//  Created by Владимир Киселев on 26.05.2022.
//

import SwiftUI

@main
struct LottieSwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
