//
//  Dark_Mode_AppApp.swift
//  Dark Mode App
//
//  Created by Marius Malyshev on 05.11.2021.
//

import SwiftUI

@main
struct DarkModeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
