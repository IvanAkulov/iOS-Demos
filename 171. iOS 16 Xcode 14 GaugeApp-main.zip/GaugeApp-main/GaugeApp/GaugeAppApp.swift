//
//  GaugeAppApp.swift
//  GaugeApp
//
//  Created by Vasichko Anna on 23.08.2022.
//

import SwiftUI

@main
struct GaugeAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
