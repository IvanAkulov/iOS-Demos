//
//  PhoneService.swift
//  TestPicker
//
//  Created by Anastasia Sokolan on 21.12.2020.
//

import UIKit

final class PhoneService {
    static var phones:[String: (String, UIImage)] =
    {
        var codes = [String:(String, UIImage)]()
        codes["BY"] = ("+375", UIImage(named: "BY") ?? UIImage())
        codes["RU"] = ("+7", UIImage(named: "RU") ?? UIImage())
        codes["ES"] = ("+34", UIImage(named: "ES") ?? UIImage())
        codes["NO"] = ("+47", UIImage(named: "NO") ?? UIImage())
        codes["SE"] = ("+46", UIImage(named: "SE") ?? UIImage())
        codes["FR"] = ("+33", UIImage(named: "FR") ?? UIImage())
        codes["NL"] = ("+31", UIImage(named: "NL") ?? UIImage())
        codes["FI"] = ("+358", UIImage(named: "FI") ?? UIImage())
        
        return codes
    }()
}
