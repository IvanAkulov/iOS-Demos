//
//  ViewController.swift
//  TestPicker
//
//  Created by Anastasia Sokolan on 21.12.2020.
//

import CoreTelephony
import UIKit

class ViewController: UIViewController {
    @IBOutlet private weak var pickerView: UIPickerView!
    
    private lazy var phonePickerModels: [PhonePickerModel] = {
        var models: [PhonePickerModel] = []
        
        for (code, value) in PhoneService.phones
        {
            models.append(.init(code: code, title: value.0, icon: value.1))
        }
        return models
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
    }
}

extension ViewController: UIPickerViewDataSource, UIPickerViewDelegate
{
    func numberOfComponents(in pickerView: UIPickerView) -> Int { return 1 }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int { return phonePickerModels.count }
    
    func pickerView(_ pickerView: UIPickerView, rowHeightForComponent component: Int) -> CGFloat {
        return 40.0
    }
    
    func pickerView(_ pickerView: UIPickerView, widthForComponent component: Int) -> CGFloat {
        return 130.0
    }
    
    func pickerView(_ pickerView: UIPickerView, viewForRow row: Int, forComponent component: Int, reusing view: UIView?) -> UIView {
        let model = phonePickerModels[row]
        return PhoneNumberView.create(icon: model.icon, title: model.title)
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if #available(iOS 14.0, *) {
            pickerView.subviews[1].backgroundColor = .clear
        }
        
        let model = phonePickerModels[row]
    }
}

private extension ViewController {
    func setup() {
        pickerView.delegate = self
        
        let countryCode: String
        if let carrier = CTTelephonyNetworkInfo().serviceSubscriberCellularProviders?.first?.value,
           let code = carrier.isoCountryCode?.uppercased() {
            countryCode = code
        } else {
            countryCode = "RU"
        }
        
        let index = phonePickerModels.firstIndex { $0.code == countryCode } ?? 0
        pickerView.selectRow(index, inComponent: 0, animated: true)
        
        if #available(iOS 14.0, *) {
            pickerView.subviews[1].backgroundColor = .clear
        }
    }
}

struct PhonePickerModel
{
    let code: String
    let title: String
    let icon: UIImage
}
