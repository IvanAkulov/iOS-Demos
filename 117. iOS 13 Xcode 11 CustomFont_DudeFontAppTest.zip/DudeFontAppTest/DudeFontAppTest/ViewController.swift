//
//  ViewController.swift
//  DudeFontAppTest
//
//  Created by Eduard Sinyakov on 4/20/20.
//  Copyright © 2020 Eduard Siniakov. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

	@IBOutlet weak var dudeText: UILabel!

	override func viewDidLoad() {
		super.viewDidLoad()
		dudeText.font = UIFont(name: "ABosaNova", size: 24)
//		for family in UIFont.familyNames.sorted() {
//			let names = UIFont.fontNames(forFamilyName: family)
//			print("Family: \(family) Font names: \(names)")
//		}
	}


}

