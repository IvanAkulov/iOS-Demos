//
//  ViewController.swift
//  TestShadowProject
//
//  Created by Anastasia Sokolan on 05.10.2020.
//  Copyright © 2020 Anastasia Sokolan. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var containerView: UIView!
    
    private let shadowView = ShadowView()
        
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setup()
    }
        
    private func setup() {
        let image = UIImage(named: "nature")
        
        containerView.addSubview(shadowView)
        shadowView.image = image
        
        shadowView.translatesAutoresizingMaskIntoConstraints = false
        
        shadowView.leadingAnchor.constraint(equalTo: containerView.leadingAnchor).isActive = true
        shadowView.trailingAnchor.constraint(equalTo: containerView.trailingAnchor).isActive = true
        shadowView.topAnchor.constraint(equalTo: containerView.topAnchor).isActive = true
        shadowView.bottomAnchor.constraint(equalTo: containerView.bottomAnchor).isActive = true
    }
}

