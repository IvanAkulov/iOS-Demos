//
//  ViewController.swift
//  Sushi App
//
//  Created by Алексей Пархоменко on 01/02/2019.
//  Copyright © 2019 Алексей Пархоменко. All rights reserved.
//


import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    

}

