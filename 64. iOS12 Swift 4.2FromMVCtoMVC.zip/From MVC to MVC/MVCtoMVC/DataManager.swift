//
//  DataManager.swift
//  MVCtoMVC
//
//  Created by Ivan Akulov on 22/10/2018.
//  Copyright © 2018 Ivan Akulov. All rights reserved.
//

import UIKit

class DataManager {
    let elements = Array(repeating: "Row ", count: 10)
    
    func add(at index: Int) {
        
    }
}
