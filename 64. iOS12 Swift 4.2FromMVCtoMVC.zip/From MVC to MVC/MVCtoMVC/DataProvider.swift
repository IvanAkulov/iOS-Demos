//
//  DataProvider.swift
//  MVCtoMVC
//
//  Created by Ivan Akulov on 22/10/2018.
//  Copyright © 2018 Ivan Akulov. All rights reserved.
//

import UIKit

enum Section: Int, CaseIterable {
    case elements
}

class DataProvider: NSObject {
    var dataManager = DataManager()
}

extension DataProvider: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dataManager.elements.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        cell.textLabel?.text = dataManager.elements[indexPath.row] + indexPath.row.description
        return cell
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return Section.allCases.count
    }
}

extension DataProvider: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("Something happens!")
    }
}
