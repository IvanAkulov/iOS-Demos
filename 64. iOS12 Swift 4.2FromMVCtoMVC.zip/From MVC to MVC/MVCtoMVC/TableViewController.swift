//
//  ViewController.swift
//  MVCtoMVC
//
//  Created by Ivan Akulov on 22/10/2018.
//  Copyright © 2018 Ivan Akulov. All rights reserved.
//

import UIKit

class TableViewController: UITableViewController {
    
    @IBOutlet var dataProvider: DataProvider!
    
    
}
