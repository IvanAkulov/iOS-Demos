//
//  ContentView.swift
//  EmojiWidget
//
//  Created by Anastasia Sokolan on 25.11.2020.
//

import SwiftUI
import WidgetKit

struct ContentView: View {
    @AppStorage("emoji", store: UserDefaults(suiteName: "group.com.anastasia.s.EmojiWidget"))
    var emojiData = Data()
    
    var body: some View {
        Button(action: {
            print("Action")
            save(EmojiProvider.random())
            WidgetCenter.shared.reloadTimelines(ofKind: "MyEmojiWidget")
        }, label: {
            Text("Tap me!")
        })
    }
    
    private func save(_ emoji: EmojiDetails) {
        guard let data = try? JSONEncoder().encode(emoji) else {
            return
        }
        emojiData = data
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
