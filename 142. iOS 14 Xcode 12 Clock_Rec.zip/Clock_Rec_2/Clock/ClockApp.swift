//
//  ClockApp.swift
//  Clock
//
//  Created by Nikita Zharinov on 29/05/2021.
//

import SwiftUI

@main
struct ClockApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
