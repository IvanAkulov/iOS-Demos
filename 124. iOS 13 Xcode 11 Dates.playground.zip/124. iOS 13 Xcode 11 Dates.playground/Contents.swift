import UIKit

let caledar = Calendar.current
let date = Date()

let dateComponents = DateComponents(calendar: caledar, year: 1999, month: 10, day: 31)
let composedDatw = caledar.date(from: dateComponents)


let componentsFromCuurentDate = caledar.dateComponents([.year, .month, .day, .hour, .minute], from: date)
let dayOfWeek = caledar.component(.weekday, from: date)

let currentMonth = caledar.date(byAdding: .month, value: 0, to: date)

let interval = caledar.dateInterval(of: .month, for: currentMonth!)

func datesRange(from: Date, to: Date) -> [Date] {
    var fromInterval = from.timeIntervalSince1970
    let toInterval = to.timeIntervalSince1970
    var dates = [Date]()
    
    while fromInterval < toInterval {
        dates.append(Date(timeIntervalSince1970: fromInterval))
        fromInterval += 60 * 60 * 24
    }
    return dates
}

for i in 0...1 {
    let date = caledar.date(byAdding: .month, value: i, to: Date())!
    let interval = caledar.dateInterval(of: .month, for: date)!
    let days = datesRange(from: interval.start, to: interval.end)
    print(days)
}


