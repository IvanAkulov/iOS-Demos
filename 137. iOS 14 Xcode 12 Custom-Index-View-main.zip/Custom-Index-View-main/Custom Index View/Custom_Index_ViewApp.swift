//
//  Custom_Index_ViewApp.swift
//  Custom Index View
//
//  Created by Brubrusha on 2/5/21.
//

import SwiftUI

@main
struct Custom_Index_ViewApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
