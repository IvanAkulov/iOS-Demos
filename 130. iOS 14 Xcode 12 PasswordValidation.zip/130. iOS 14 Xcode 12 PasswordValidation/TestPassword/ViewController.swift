//
//  ViewController.swift
//  TestPassword
//
//  Created by Anastasia Sokolan on 17.11.2020.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var textField: UITextField!
    @IBOutlet weak var messageLabel: UILabel!
    
    private let minLength = 6
    private lazy var regex = "^(?=.*[а-я])(?=.*[А-Я])(?=.*\\d)(?=.*[$@$!%*?&#])[А-Яа-я\\d$@$!%*?&#]{\(minLength),}$"
    private let password = "АБаб$12"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        textField.delegate = self
        messageLabel.numberOfLines = 0
    }
    
    private func checkValidation(password: String) {
        guard password.count >= minLength else {
            messageLabel.text = ""
            return
        }
        
        if password.matches(regex) {
            messageLabel.textColor = .green
            messageLabel.text = "Верные символы в пароле!"
        } else {
            messageLabel.textColor = .white
            messageLabel.text = "Минимум \(minLength) символов\nДолжен содержать: \n1 большую букву,\n1 маленькую букву,\n1 цифру и\n1специальный символ"
        }
    }
}

extension ViewController: UITextFieldDelegate {
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let text = (textField.text ?? "") + string
        let res: String
        
        if range.length == 1 {
            let end = text.index(text.startIndex, offsetBy: text.count - 1)
            res = String(text[text.startIndex..<end])
        } else {
            res = text
        }
        
        checkValidation(password: res)
        textField.text = res
        return false
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        let isSuccess = (textField.text == password)
        messageLabel.textColor = isSuccess ? .green : .red
        messageLabel.text = isSuccess ? "Success" : "Error"
        textField.resignFirstResponder()
        return true
    }
}

extension String {
    func matches(_ regex: String) -> Bool {
        return self.range(of: regex, options: .regularExpression, range: nil, locale: nil) != nil
    }
}
