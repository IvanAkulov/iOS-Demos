// Перечисления со связанными значениями
// Swiftbook.ru
// Marius

//enum GoodType {
//    case bag
//    case camera
//}
//
//struct GoodCharacteristics {
//    let type: GoodType
//    let name: String
//    let volume: Double?
//    let resolution: String?
//}

enum Good {
    case bag(name: String, volume: Double)
    case camera(name: String, resolution: String)
}

let good = Good.bag(name: "Bobby", volume: 5)

print(good)

//good.name
//good.volume

if case let Good.bag(name, volume) = good {
    print(name)
    print(volume)
}

extension Good {
    var name: String {
        switch self {
        case .bag(let name, _),
             .camera(let name, _):
            return name
        }
    }
}

print(good.name)

Optional
Result
