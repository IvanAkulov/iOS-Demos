//
//  ViewController.swift
//  KVO&KVC SwiftBook.ru
//
//  Created by Алексей Пархоменко on 22/03/2019.
//  Copyright © 2019 Алексей Пархоменко. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var textLabel: UILabel!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var textField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

    @IBAction func buttonTapped(_ sender: Any) {
    }
    
    @IBAction func textFieldEditingChanged(_ sender: Any) {
    }
    
}

