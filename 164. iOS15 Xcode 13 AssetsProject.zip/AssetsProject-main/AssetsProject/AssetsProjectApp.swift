//
//  AssetsProjectApp.swift
//  AssetsProject
//
//  Created by Vasichko Anna on 23.06.2022.
//

import SwiftUI

@main
struct AssetsProjectApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
