//
//  photoPickerAppApp.swift
//  photoPickerApp
//
//  Created by Vasichko Anna on 12.08.2022.
//

import SwiftUI

@main
struct photoPickerAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
