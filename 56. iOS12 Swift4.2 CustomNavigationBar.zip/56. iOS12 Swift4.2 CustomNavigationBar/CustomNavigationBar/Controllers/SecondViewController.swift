//
//  SecondViewController.swift
//  CustomNavigationBar
//
//  Created by Ivan Akulov on 23/07/2018.
//  Copyright © 2018 Ivan Akulov. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {
    
    enum CellIdentifiers: String {
        case cell
        
        var identifier: String {
            return self.rawValue
        }
    }
    
    @IBOutlet var tableView: UITableView!
    var faqs = ["Let it be a question",
                "Let it be another question",
                "Let it be another question",
                "Let it be another question",
                "Let it be another question",
                "Let it be another question",
                "Let it be another question",
                "Let it be another question",
                "Let it be another question",
                "Let it be another question"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupTableView()
        setupNavigationBar()
    }
    
    func setupNavigationBar() {

        let imageView = UIImageView(image: #imageLiteral(resourceName: "info@3x.png"))
        imageView.frame = CGRect(x: 0, y: 0, width: 30, height: 30)
        imageView.contentMode = .scaleAspectFit
        
        let label = UILabel()
        label.text = "FAQ"
        label.font = UIFont(name: "OpenSansCondensed-Bold", size: 30)
        label.textColor = .white
        
        let stackView = UIStackView(arrangedSubviews: [imageView, label])
        stackView.axis = .horizontal
        stackView.frame.size = CGSize(width: imageView.frame.size.width + label.frame.size.width, height: max(imageView.frame.size.height, label.frame.size.height))
        stackView.spacing = 20
        
        navigationItem.titleView = stackView
        
        if #available(iOS 11.0, *) {
            navigationItem.largeTitleDisplayMode = .never
        }
        
    }
    
    func setupTableView() {
        tableView.backgroundColor = .orange
        tableView.separatorColor = .white
    }
}

extension SecondViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//        let cell = tableView.cellForRow(at: indexPath)
//        print((cell?.textLabel?.text)!)
    }
}

extension SecondViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return faqs.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: CellIdentifiers.cell.identifier, for: indexPath)
        let question = faqs[indexPath.row]
        cell.textLabel?.text = question
        cell.textLabel?.textColor = .white
        cell.backgroundColor = .orange
        return cell
    }
}
