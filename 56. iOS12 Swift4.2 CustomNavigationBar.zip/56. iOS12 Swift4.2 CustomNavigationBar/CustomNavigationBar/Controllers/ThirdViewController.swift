//
//  ThirdViewController.swift
//  CustomNavigationBar
//
//  Created by Ivan Akulov on 23/07/2018.
//  Copyright © 2018 Ivan Akulov. All rights reserved.
//

import UIKit

class ThirdViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupNavigationBar()
    }
    
    func setupNavigationBar() {
        
        
    }
}
