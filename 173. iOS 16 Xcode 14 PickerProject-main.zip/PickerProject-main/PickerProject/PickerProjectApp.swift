//
//  PickerProjectApp.swift
//  PickerProject
//
//  Created by Vasichko Anna on 08.09.2022.
//

import SwiftUI

@main
struct PickerProjectApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
