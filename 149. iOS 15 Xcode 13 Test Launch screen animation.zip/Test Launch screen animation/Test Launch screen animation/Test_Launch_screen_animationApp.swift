//
//  Test_Launch_screen_animationApp.swift
//  Test Launch screen animation
//
//  Created by Marius Malyshev on 12.11.2021.
//

import SwiftUI

@main
struct Test_Launch_screen_animationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
