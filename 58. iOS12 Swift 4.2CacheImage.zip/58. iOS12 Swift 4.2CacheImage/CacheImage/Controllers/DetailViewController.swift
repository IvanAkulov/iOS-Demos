//
//  DetailViewController.swift
//  CacheImage
//
//  Created by Ivan Akulov on 20/08/2018.
//  Copyright © 2018 Ivan Akulov. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController {
    
    @IBOutlet var imageView: UIImageView!
    @IBOutlet var activityIndicatorView: UIActivityIndicatorView!
    
    var dataProvider: DataProvider!
    
    private var image: UIImage? {
        didSet {
            imageView.image = image
            activityIndicatorView.stopAnimating()
            activityIndicatorView.isHidden = true
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        activityIndicatorView.startAnimating()
        activityIndicatorView.isHidden = false
        
        let urlString = "https://images7.alphacoders.com/671/671281.jpg"
        let url = URL(string: urlString)!
        dataProvider.downloadImage(url: url) { image in
            self.image = image
        }
    }
    
    deinit {
        print("controller dismissed")
    }
}
