//
//  ViewController.swift
//  CacheImage
//
//  Created by Ivan Akulov on 20/08/2018.
//  Copyright © 2018 Ivan Akulov. All rights reserved.
//

import UIKit

class TableViewController: UITableViewController {
    
    enum SegueIdentifiers: String {
        case detailSegue
    }
    
    enum CellIdentifiers: String {
        case cell
    }
    
    let dataProvider = DataProvider()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let nib = UINib(nibName: String(describing: TableViewCell.self), bundle: nil)
        tableView.register(nib, forCellReuseIdentifier: CellIdentifiers.cell.rawValue)
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard let identifier = segue.identifier, identifier == SegueIdentifiers.detailSegue.rawValue,
        let dvc = segue.destination as? DetailViewController else { return }
        dvc.dataProvider = dataProvider
    }
}


// MARK: - UITableViewDataSource
extension TableViewController {
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 10
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: CellIdentifiers.cell.rawValue, for: indexPath) as! TableViewCell
        
        return cell
    }
}


// MARK: - UITableViewDelegate
extension TableViewController {
    override func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return 140
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: SegueIdentifiers.detailSegue.rawValue, sender: self)
    }
}

