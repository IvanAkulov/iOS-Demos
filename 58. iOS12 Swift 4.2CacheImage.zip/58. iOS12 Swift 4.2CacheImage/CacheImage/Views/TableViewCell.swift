//
//  TableViewCell.swift
//  CacheImage
//
//  Created by Ivan Akulov on 20/08/2018.
//  Copyright © 2018 Ivan Akulov. All rights reserved.
//

import UIKit

class TableViewCell: UITableViewCell {
    
    @IBOutlet var myImageView: UIImageView!
    
}
