import UIKit

//: ## Некоторые нововведения Swift 5.7
// Упрощенный синтаксис опциональной привязки

var age: Int? = 19

if let age = age {
    print("I guess he is \(age) years old")
}

if let age {
    print("I guess he is \(age) years old")
}

func printAge(age: Int?) {
    guard let age else { return }
    print("I guess he is \(age) years old")
}

printAge(age: age)


class Boy {
    let age: Int
    
    init(age: Int) {
        self.age = age
    }
}

let boy: Boy? = Boy(age: 12)


if let age = boy?.age {
    print("I guess he is \(age) years old")
}


// Облегченный синтаксис замыканий

let points = [65, 80, 90, 75]

let examResults = points.map { point in
    if point >= 75 {
        return "\(point): High Score"
    } else {
        return "\(point): Low Score"
    }
}

for examResult in examResults {
    print(examResult)
}


// Новый стандарт работы с временными отрезками
// Clocks
// Instants
// Durations

let clock = ContinuousClock()

let time = clock.measure {
    // some code here
}

print("The file export took \(time.components.seconds) seconds")



// Улучшенная обработка строк и регулярных выражений

let text = "WE dream of ice-cream"

print(text.replacing("we", with: "they"))
print(text.trimmingPrefix("we "))

print(text.replacing(/[c-d]ream/, with: "out"))
print(text.trimmingPrefix(/We/.ignoresCase()))

do {
    let someSearch = try Regex("[c-d]ream")
    print(text.replacing(someSearch, with: "out"))
} catch {
    "failure"
}


// Ключевые слова some и any

//func doSomething(with a: some MyProtocol) {
//    // do something
//}
//
//func doSomething(with a: any MyProtocol) {
//    // do something
//}


protocol Animal {
    var name: String { get }
}

struct Dog: Animal {
    let name = "dog"
}

struct Cat: Animal {
    let name = "cat"
}

func feed(animal: some Animal) {
    // some code
}

let animals: [some Animal] = [
    Dog(),
    Dog(),
    Dog()
]

func showAllAnimals() -> [some Animal] {
    animals
}

let newAnimals: [any Animal] = [
    Dog(),
    Dog(),
    Cat(),
    Cat()
]

var myAnimal: any Animal = Dog()
myAnimal = Cat()
