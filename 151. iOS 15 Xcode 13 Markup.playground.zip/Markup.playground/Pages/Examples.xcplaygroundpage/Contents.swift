//: [Пользовательская сноска](@previous)

/*:
 ````
 Код
в несколько
 строк
 ````
 */

/*:
    Код без кавычек
        в несколько
    строк
 */

/*: Описание
    
    for character in "some text" {
        some code
    }
 */

/*:
 Пример с несколькими отступами:
 
    if true {
 
        if true {
 
            if true {
                some code
            }
        }
    }
 */

/*:
 - Example:
    for {\
        if {\
        }
    }
 */

//: [Эксперимент](@next)
