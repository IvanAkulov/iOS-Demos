/*:
 ## Содержание:
 [Метки](Markup)\
 [Перенос строки](Escapes)\
 [Специальные символы](SpecialCharacters)\
 [Разделительная линия](HorizontalRules)\
 [Переход между страницами](AddingPages)\
 [Заголовки](Heading)
 - Callout(Списки):
 [Маркированные](BuletedLists)\
 [Нумерованные](NumeredLists)

 [Шрифты](Fonts)

 [Ссылки](Links)\
 [Картинки](Images)\
 [Видео](Videos)
 - Callout(Сноски):
 [Пользовательская](CustomCallout)\
 [Пример](Examples)\
 [Задание](Experiment)\
 [Важно](Important)\
 [Заметка](Notes)
 
 Если в названии файла есть пробелы, то они заменяются знаком `%20`
 */
