//
//  GestureStateApp.swift
//  GestureState
//
//  Created by Marius Malyshev on 06.12.2021.
//

import SwiftUI

@main
struct GestureStateApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
