//
//  NavProjectApp.swift
//  NavProject
//
//  Created by Vasichko Anna on 05.07.2022.
//

import SwiftUI

@main
struct NavProjectApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
