//
//  ShareProjectApp.swift
//  ShareProject
//
//  Created by Vasichko Anna on 16.09.2022.
//

import SwiftUI

@main
struct ShareProjectApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
